<?php

namespace App\Database\Migrations;
use CodeIgniter\Database\Migration;

class User extends Migration
{
    //Method up() digunakan untuk menjalankan migrasi dan membuat tabel
    public function up()
    {
        $field = 
        [
            'id'=> [
                'type' => 'INT',
                'constraint' => 5,
                'unsigned' => true,
                'auto_increment' => true
            ],
            'username' => [
                'type' => 'VARCHAR',
                'constraint' => 100,
            ],
            'email' => [
                'type' => 'VARCHAR',
                'constraint' => 100,
            ],
            'password' => [
                'type' => 'TEXT',

            ],
            'created_at' => [
                'type' => 'DATETIME',
            ],
            'updated_at' => [
                'type' => 'DATETIME',
            ],
            'deleted_at' => [
                'type' => 'DATETIME',
            ],
        ];

        //menambah kolom pada tabel
        $this->forge->addField($field);
        //menentukan primarykey pada tabel
        $this->forge->addKey('id', true);
        //membuat tabel
        $this->forge->createTable('user', true);
    }

    //Method down() digunakan untuk membatalkan migrasi dan menghapus tabel
    public function down()
    {
        //menghapus tabel
        $this->forge->dropTable('user', true);
    }
}