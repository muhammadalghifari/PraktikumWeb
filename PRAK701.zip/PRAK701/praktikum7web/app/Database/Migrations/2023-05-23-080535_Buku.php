<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class Crud extends Migration
{
    //Method up() digunakan untuk menjalankan migrasi dan membuat tabel
    public function up()
    {
        $field = 
        [
            "id" => [
                'type' => 'BIGINT',
                'constraint' => 5,
                'auto_increment' => TRUE,
                'unsigned' => true
            ],
            'judul' => [
                'type' => 'VARCHAR',
                'constraint' => 50
            ],
            'penulis' => [
                'type' => 'VARCHAR',
                'constraint' => 20
            ],
            'penerbit' => [
                'type' => 'VARCHAR',
                'constraint' => 20
            ],
            'tahun_terbit' => [
                'type' => 'YEAR',
                'constraint' => 20
            ]
        ];

        //menambah kolom pada tabel
        $this->forge->addField($field);
        //menentukan primarykey pada tabel
        $this->forge->addKey('id',true);
        //membuat tabel
        $this->forge->createTable('buku', true);
    }

    //Method down() digunakan untuk membatalkan migrasi dan menghapus tabel
    public function down()
    {
        //menghapus tabel
        $this->forge->dropTable('buku', true);
    }
}