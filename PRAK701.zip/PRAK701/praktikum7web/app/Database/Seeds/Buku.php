<?php

namespace App\Database\Seeds;

//Import class Seeder untuk membuat seeder tertentu
use CodeIgniter\Database\Seeder;
//Import class BukuModel untuk diisi data pada tabel buku di database
use App\Models\BukuModel;

//Deklarasi class ekstensi Seeder, yang akan mengisi Class buku dengan data awal untuk dimasukkan ke dalam database.
class Buku extends Seeder
{
    public function run()
    {
        $this->db->table('buku')->insert([
            'judul' => 'The Olympus',
            'penulis' => 'Rick Riordan',
            'penerbit' => 'Mizan',
            'tahun_terbit' => '2010'
        ]);
}
} 